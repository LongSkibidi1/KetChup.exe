# &#x20;            KetChup.exe

Please run the dangerous version in a VM

It has a safe version, you can run it on a physical machine or a virtual machine

GitHub:LongSkibidi1

